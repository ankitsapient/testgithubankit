<?php
class Excellence_Ship_IndexController extends Mage_Core_Controller_Front_Action
{
    
}